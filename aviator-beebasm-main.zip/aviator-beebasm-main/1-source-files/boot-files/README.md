# Boot files for the BBC Micro disc version of Aviator

This folder contains the boot file from the BBC Micro disc version of Aviator.

* [$.!BOOT.bin]($.!BOOT.bin) is the boot file from the game disc, which runs $.AVIA

---

_Mark Moxon_