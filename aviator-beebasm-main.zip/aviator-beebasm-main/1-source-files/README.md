# Source files for the BBC Micro disc version of Aviator

This folder contains the source files for the BBC Micro disc version of Aviator.

* [basic-programs](basic-programs) contains any BASIC programs to be included on the final game disc

* [boot-files](boot-files) contains any !BOOT files to be included on the final game disc

* [images](images) contains the image binaries for the dashboard

* [main-sources](main-sources) contains the annotated source code

---

_Mark Moxon_